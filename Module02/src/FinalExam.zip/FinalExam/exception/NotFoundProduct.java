package FinalExam.exception;

public class NotFoundProduct extends Exception {
    public NotFoundProduct(String message) {
        super(message);
    }
}
