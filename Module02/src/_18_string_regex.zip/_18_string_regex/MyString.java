package _18_string_regex;

public class MyString {
    public static void main(String[] args) {
//        String str1 = "abc";
//        String str2 = str1;
//        System.out.println(str1 == str2);
//
//        String name1 = new String("Anh");
//        String name2 = new String("Anh");
//        System.out.println(name1 == name2);
//        System.out.println(name1.equals(name2));

//        String str4 = "anh";
//        String str5 = str4;
//        str5 += " hung";
//        System.out.println(str4);
//        System.out.println(str5);

//        String str4 = new String("anh");
//        String str5 = str4;
//        str5 += " hung";
//        System.out.println(str4);
//        System.out.println(str5);
//        String str6 = new String("   abcdfrt   ");
//        str6.substring(0,3); //str7
//        System.out.println(str6.trim());
//        System.out.println(str6);


        String str4 = "anh";
        String str5 = str4;
        str5 += str4.concat(" Hung");
        System.out.println(str4); //anh
        System.out.println(str5); // anh Hung

        StringBuffer str1 = new StringBuffer("anh");
        StringBuffer str2 = str1;
        str2.append(" hung"); //concat
        System.out.println(str1); //anh
        System.out.println(str2); //anh

        int index = 10;
        StringBuilder stringBuilder = new StringBuilder();
        for(int i = 1; i <= index; i++){
            stringBuilder.append(i);
        }
        System.out.println(stringBuilder);
    }
}
