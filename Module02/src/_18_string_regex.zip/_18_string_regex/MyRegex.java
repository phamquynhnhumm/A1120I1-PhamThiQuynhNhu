package _18_string_regex;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MyRegex {

    public static final String REGEX_ID = "\\d{3}";
    public static final String REGEX_VISA = "\\d{4} \\d{4}";

    public static void main(String[] args) {
//        Pattern pattern = Pattern.compile(REGEX_VISA);
//        Matcher matcher = pattern.matcher("12534 1234");
//        System.out.println(matcher.matches());

        System.out.println("1234 12634".matches(REGEX_VISA));
    }
}
