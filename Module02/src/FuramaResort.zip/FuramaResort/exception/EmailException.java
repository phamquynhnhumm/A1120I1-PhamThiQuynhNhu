package FuramaResort.exception;

public class EmailException extends  Exception{
    public  EmailException(){
        super("Định dang L Email phai là abc@gmail.com");
    }
}
