package FuramaResort.exception;

public class IdCardExcetion extends Exception {
    public IdCardExcetion()
    {
        super("Chứng minh nhân dân phải gồm 9 chữ số");
    }
}
