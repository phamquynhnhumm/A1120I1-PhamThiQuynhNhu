package FuramaResort.exception;

public class NameException extends Exception {
    public NameException() {
        super("Định dang : Tên khách hàng phải in hoa kí tự đầu tiên trong mỗi từ.");
    }


}
