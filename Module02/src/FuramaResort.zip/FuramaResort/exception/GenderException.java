package FuramaResort.exception;

public class GenderException extends Exception{
    public  GenderException()
    {
        super("Định dang : Giới tính phải nhập Nam hoặc Nữ");
    }
}
